#include <stdlib.h>

#include "table.h"


struct table
{
    // TODO
};


table *table_empty(int capacity, key_compare_func cmp, key_hash_func hash)
{
    table *t;
    t = malloc(sizeof *t);
    // TODO
    return t;
}


bool table_is_empty(table *t)
{
    // TODO
    return true;
}


void table_insert(table *t, KEY key, VALUE val)
{
    // TODO
}


VALUE table_lookup(table *t, KEY key)
{
    // TODO
    return NULL;
}


void table_remove(table *t, KEY key)
{
    // TODO
}


void table_kill(table *t)
{
    // TODO
    free(t);
}
